#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
java -version
gradle --version
gradle clean build
echo "JAR gerado em build/libs/LivingCity-0.1.0.jar"
