package com.livingcity.entity;

public enum NPCAnimationState {
    IDLE, WALKING, TALKING, OBSERVING
}
