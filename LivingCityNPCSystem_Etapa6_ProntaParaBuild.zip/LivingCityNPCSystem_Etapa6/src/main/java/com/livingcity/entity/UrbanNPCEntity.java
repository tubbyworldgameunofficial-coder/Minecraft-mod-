package com.livingcity.entity;

import com.livingcity.ai.NPCBrain;
import com.livingcity.navigation.NPCPathController;
import com.livingcity.ai.goals.ObservePlayerGoal;
import com.livingcity.ai.goals.SocializeGoal;
import com.livingcity.ai.goals.UrbanGraphNavigationGoal;
import com.livingcity.ai.goals.CrossStreetGoal;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.UUID;

public class UrbanNPCEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> NPC_NAME =
            SynchedEntityData.defineId(UrbanNPCEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> AI_STATE =
            SynchedEntityData.defineId(UrbanNPCEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PERSONALITY =
            SynchedEntityData.defineId(UrbanNPCEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> SKIN_INDEX =
            SynchedEntityData.defineId(UrbanNPCEntity.class, EntityDataSerializers.INT);

    private UUID persistentNpcId = UUID.randomUUID();
    private final NPCPathController cityPath = new NPCPathController(this);

    public UrbanNPCEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 24.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.1D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(NPC_NAME, "Morador");
        entityData.define(AI_STATE, NPCAnimationState.IDLE.ordinal());
        entityData.define(PERSONALITY, NPCPersonality.CALM.ordinal());
        entityData.define(SKIN_INDEX, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(2, new SocializeGoal(this));
        goalSelector.addGoal(4, new ObservePlayerGoal(this, 9.0D));
        goalSelector.addGoal(5, new CrossStreetGoal(this));
        goalSelector.addGoal(6, new UrbanGraphNavigationGoal(this, 32.0D));
        // Fallback behavior when no city graph has been authored in this area.
        goalSelector.addGoal(7, new RandomStrollGoal(this, 0.85D, 80));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            if (tickCount == 1) {
                if (getRandom().nextFloat() < 0.35F) {
                    setPersonality(NPCPersonality.values()[getRandom().nextInt(NPCPersonality.values().length)]);
                }
                // Each newly spawned resident receives one of the supplied skins.
                setSkinIndex(getRandom().nextInt(5));
            }
            NPCBrain.serverThink(this);
            if (tickCount % 10 == 0 && getNpcState() != NPCAnimationState.TALKING
                    && getNpcState() != NPCAnimationState.OBSERVING) {
                refreshStateFromNavigation();
            }
        }
    }

    public String getNpcName() { return entityData.get(NPC_NAME); }

    public void setNpcName(String name) {
        if (name != null && !name.isBlank()) entityData.set(NPC_NAME, name);
    }

    public NPCAnimationState getNpcState() {
        return NPCAnimationState.byId(entityData.get(AI_STATE));
    }

    public void setNpcState(NPCAnimationState state) {
        if (!level().isClientSide && state != null) entityData.set(AI_STATE, state.ordinal());
    }

    public void refreshStateFromNavigation() {
        if (level().isClientSide) return;
        setNpcState(getNavigation().isInProgress()
                ? NPCAnimationState.WALKING : NPCAnimationState.IDLE);
    }

    /** Zero-based skin selector (0..4), synchronized to clients. */
    public int getSkinIndex() {
        return Math.max(0, Math.min(4, entityData.get(SKIN_INDEX)));
    }

    public void setSkinIndex(int index) {
        if (!level().isClientSide) entityData.set(SKIN_INDEX, Math.max(0, Math.min(4, index)));
    }

    public NPCPersonality getPersonality() {
        return NPCPersonality.byId(entityData.get(PERSONALITY));
    }

    public void setPersonality(NPCPersonality personality) {
        if (!level().isClientSide && personality != null)
            entityData.set(PERSONALITY, personality.ordinal());
    }

    public UUID getPersistentNpcId() { return persistentNpcId; }
    public NPCPathController getCityPath() { return cityPath; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("LivingCityName", getNpcName());
        tag.putString("LivingCityUUID", persistentNpcId.toString());
        tag.putInt("LivingCityState", getNpcState().ordinal());
        tag.putInt("LivingCityPersonality", getPersonality().ordinal());
        tag.putInt("LivingCitySkin", getSkinIndex());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("LivingCityName")) setNpcName(tag.getString("LivingCityName"));
        if (tag.hasUUID("LivingCityUUID")) persistentNpcId = tag.getUUID("LivingCityUUID");
        if (tag.contains("LivingCityState")) setNpcState(NPCAnimationState.byId(tag.getInt("LivingCityState")));
        if (tag.contains("LivingCityPersonality"))
            setPersonality(NPCPersonality.byId(tag.getInt("LivingCityPersonality")));
        if (tag.contains("LivingCitySkin")) setSkinIndex(tag.getInt("LivingCitySkin"));
    }
}
