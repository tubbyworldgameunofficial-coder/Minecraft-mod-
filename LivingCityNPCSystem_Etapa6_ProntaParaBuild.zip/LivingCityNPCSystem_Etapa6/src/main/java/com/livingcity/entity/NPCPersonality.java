package com.livingcity.entity;

/** Lightweight personality profile used by server-side decision making. */
public enum NPCPersonality {
    CALM(0.82D, 0.22D, 7.0D),
    SOCIAL(0.92D, 0.82D, 9.0D),
    CURIOUS(0.88D, 0.48D, 12.0D),
    SHY(0.78D, 0.10D, 5.0D),
    ENERGETIC(1.08D, 0.38D, 8.0D);

    private final double walkMultiplier;
    private final double socialChance;
    private final double perception;

    NPCPersonality(double walkMultiplier, double socialChance, double perception) {
        this.walkMultiplier = walkMultiplier;
        this.socialChance = socialChance;
        this.perception = perception;
    }

    public double walkMultiplier() { return walkMultiplier; }
    public double socialChance() { return socialChance; }
    public double perception() { return perception; }

    public static NPCPersonality byId(int id) {
        NPCPersonality[] values = values();
        return id >= 0 && id < values.length ? values[id] : CALM;
    }
}
