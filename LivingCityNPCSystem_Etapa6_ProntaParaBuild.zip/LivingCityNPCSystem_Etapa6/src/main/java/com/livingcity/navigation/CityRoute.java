package com.livingcity.navigation;

import java.util.List;
import java.util.UUID;

public record CityRoute(List<UUID> waypointIds, double totalCost) {
    public CityRoute {
        waypointIds = List.copyOf(waypointIds);
    }
    public boolean isEmpty() { return waypointIds.isEmpty(); }
}
