package com.livingcity.navigation;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.Optional;

/**
 * Validates a proposed crossing between two urban graph nodes.
 * This is a conservative geometric/block check, not a full traffic simulation.
 */
public final class StreetCrossingManager {
    private StreetCrossingManager() {}

    public static boolean isCrossing(CityWaypoint from, CityWaypoint to) {
        return from.type() == WaypointType.CROSSWALK || to.type() == WaypointType.CROSSWALK;
    }

    public static boolean isSafeStandingPosition(ServerLevel level, BlockPos feet) {
        BlockPos floorPos = feet.below();
        BlockState floor = level.getBlockState(floorPos);
        BlockState body = level.getBlockState(feet);
        BlockState head = level.getBlockState(feet.above());
        FluidState fluid = level.getFluidState(feet);
        return floor.blocksMotion()
                && body.getCollisionShape(level, feet).isEmpty()
                && head.getCollisionShape(level, feet.above()).isEmpty()
                && fluid.isEmpty();
    }

    /**
     * Check every block position along a straight segment at the entity's feet level.
     * The native pathfinder still calculates the actual walkable path to each node.
     */
    public static boolean isSegmentClear(ServerLevel level, BlockPos from, BlockPos to) {
        int steps = Math.max(Math.abs(to.getX() - from.getX()),
                Math.max(Math.abs(to.getY() - from.getY()), Math.abs(to.getZ() - from.getZ())));
        if (steps == 0) return isSafeStandingPosition(level, from);
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            BlockPos pos = new BlockPos(
                    (int)Math.floor(from.getX() + (to.getX() - from.getX()) * t),
                    (int)Math.floor(from.getY() + (to.getY() - from.getY()) * t),
                    (int)Math.floor(from.getZ() + (to.getZ() - from.getZ()) * t));
            if (!isSafeStandingPosition(level, pos)) return false;
        }
        return true;
    }

    public static Optional<CityWaypoint> findOppositeCrosswalk(
            CityNavigationGraph graph, CityWaypoint current, double maxDistance) {
        if (current.type() != WaypointType.CROSSWALK
                && current.type() != WaypointType.STREET_CORNER
                && current.type() != WaypointType.SIDEWALK) return Optional.empty();

        return graph.nodes().stream()
                .filter(CityWaypoint::enabled)
                .filter(node -> !node.id().equals(current.id()))
                .filter(node -> node.type() == WaypointType.CROSSWALK
                        || node.type() == WaypointType.STREET_CORNER
                        || node.type() == WaypointType.SIDEWALK)
                .filter(node -> node.position().distToCenterSqr(current.position())
                        <= maxDistance * maxDistance)
                .filter(node -> current.connections().contains(node.id()))
                .min((a, b) -> Double.compare(
                        a.position().distToCenterSqr(current.position()),
                        b.position().distToCenterSqr(current.position())));
    }
}
