package com.livingcity.navigation;

public enum WaypointType {
    SIDEWALK, ROAD, CROSSWALK, INTERSECTION, PARK, BUILDING_ENTRANCE, STREET_CORNER
}
