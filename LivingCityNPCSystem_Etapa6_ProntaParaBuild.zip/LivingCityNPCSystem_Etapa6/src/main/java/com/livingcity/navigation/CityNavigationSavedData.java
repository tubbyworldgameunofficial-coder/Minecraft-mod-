package com.livingcity.navigation;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

public class CityNavigationSavedData extends SavedData {
    private final CityNavigationGraph graph = new CityNavigationGraph();

    public CityNavigationGraph graph() { return graph; }

    public static CityNavigationSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                CityNavigationSavedData::load,
                CityNavigationSavedData::new,
                "livingcity_navigation");
    }

    public static CityNavigationSavedData load(CompoundTag tag) {
        CityNavigationSavedData data = new CityNavigationSavedData();
        data.graph.load(tag);
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.merge(graph.save());
        return tag;
    }
}
