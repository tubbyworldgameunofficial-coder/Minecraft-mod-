package com.livingcity.navigation;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.*;

/**
 * Per-level waypoint graph. This graph selects urban corridors; vanilla navigation
 * remains responsible for walking safely between successive graph nodes.
 */
public final class CityNavigationGraph {
    private final Map<UUID, CityWaypoint> nodes = new LinkedHashMap<>();

    public Collection<CityWaypoint> nodes() {
        return Collections.unmodifiableCollection(nodes.values());
    }

    public Optional<CityWaypoint> get(UUID id) { return Optional.ofNullable(nodes.get(id)); }
    public int size() { return nodes.size(); }

    public boolean add(CityWaypoint waypoint) {
        return nodes.putIfAbsent(waypoint.id(), waypoint) == null;
    }

    public boolean remove(UUID id) {
        if (nodes.remove(id) == null) return false;
        nodes.values().forEach(node -> node.disconnect(id));
        return true;
    }

    public boolean connect(UUID a, UUID b, boolean bidirectional) {
        CityWaypoint first = nodes.get(a), second = nodes.get(b);
        if (first == null || second == null || a.equals(b)) return false;
        first.connect(b);
        if (bidirectional) second.connect(a);
        return true;
    }

    public Optional<CityWaypoint> nearest(BlockPos position, double maxDistance) {
        double limit = maxDistance * maxDistance;
        return nodes.values().stream().filter(CityWaypoint::enabled)
                .filter(n -> n.position().distToCenterSqr(position) <= limit)
                .min(Comparator.comparingDouble(n -> n.position().distToCenterSqr(position)));
    }

    public Optional<CityRoute> findRoute(UUID startId, UUID goalId) {
        CityWaypoint start = nodes.get(startId), goal = nodes.get(goalId);
        if (start == null || goal == null || !start.enabled() || !goal.enabled())
            return Optional.empty();

        Map<UUID, Double> gScore = new HashMap<>();
        Map<UUID, UUID> cameFrom = new HashMap<>();
        PriorityQueue<QueueNode> open = new PriorityQueue<>(
                Comparator.comparingDouble(QueueNode::fScore));
        Set<UUID> closed = new HashSet<>();

        gScore.put(startId, 0.0D);
        open.add(new QueueNode(startId, heuristic(start, goal)));

        while (!open.isEmpty()) {
            UUID currentId = open.poll().id();
            if (!closed.add(currentId)) continue;
            if (currentId.equals(goalId)) {
                List<UUID> path = reconstruct(cameFrom, currentId);
                return Optional.of(new CityRoute(path, gScore.get(currentId)));
            }
            CityWaypoint current = nodes.get(currentId);
            if (current == null) continue;

            for (UUID neighborId : current.connections()) {
                CityWaypoint neighbor = nodes.get(neighborId);
                if (neighbor == null || !neighbor.enabled() || closed.contains(neighborId)) continue;
                double tentative = gScore.get(currentId) + edgeCost(current, neighbor);
                if (tentative < gScore.getOrDefault(neighborId, Double.POSITIVE_INFINITY)) {
                    cameFrom.put(neighborId, currentId);
                    gScore.put(neighborId, tentative);
                    open.add(new QueueNode(neighborId, tentative + heuristic(neighbor, goal)));
                }
            }
        }
        return Optional.empty();
    }

    private static double heuristic(CityWaypoint a, CityWaypoint b) {
        return a.distanceTo(b);
    }

    private static double edgeCost(CityWaypoint a, CityWaypoint b) {
        double cost = a.distanceTo(b);
        // A small preference for marked crosswalks encourages legal crossings.
        if (a.type() == WaypointType.CROSSWALK || b.type() == WaypointType.CROSSWALK)
            cost *= 0.92D;
        return cost;
    }

    private static List<UUID> reconstruct(Map<UUID, UUID> cameFrom, UUID current) {
        LinkedList<UUID> result = new LinkedList<>();
        result.addFirst(current);
        while (cameFrom.containsKey(current)) {
            current = cameFrom.get(current);
            result.addFirst(current);
        }
        return result;
    }

    private record QueueNode(UUID id, double fScore) {}

    /** Basic safety check used before an NPC asks vanilla navigation to walk to a node. */
    public static boolean isWalkable(ServerLevel level, BlockPos feet) {
        BlockPos below = feet.below();
        BlockState floor = level.getBlockState(below);
        BlockState body = level.getBlockState(feet);
        BlockState head = level.getBlockState(feet.above());
        FluidState fluid = level.getFluidState(feet);
        return floor.blocksMotion() && body.getCollisionShape(level, feet).isEmpty()
                && head.getCollisionShape(level, feet.above()).isEmpty()
                && fluid.isEmpty();
    }

    public CompoundTag save() {
        CompoundTag root = new CompoundTag();
        ListTag list = new ListTag();
        for (CityWaypoint node : nodes.values()) {
            CompoundTag tag = new CompoundTag();
            tag.putUUID("Id", node.id());
            tag.putInt("X", node.position().getX());
            tag.putInt("Y", node.position().getY());
            tag.putInt("Z", node.position().getZ());
            tag.putInt("Type", node.type().ordinal());
            tag.putBoolean("Enabled", node.enabled());
            ListTag links = new ListTag();
            for (UUID link : node.connections()) {
                CompoundTag linkTag = new CompoundTag();
                linkTag.putUUID("Id", link);
                links.add(linkTag);
            }
            tag.put("Connections", links);
            list.add(tag);
        }
        root.put("Waypoints", list);
        return root;
    }

    public void load(CompoundTag root) {
        nodes.clear();
        ListTag list = root.getList("Waypoints", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag tag = list.getCompound(i);
            int typeId = tag.getInt("Type");
            WaypointType[] types = WaypointType.values();
            WaypointType type = typeId >= 0 && typeId < types.length
                    ? types[typeId] : WaypointType.SIDEWALK;
            CityWaypoint node = new CityWaypoint(tag.getUUID("Id"),
                    new BlockPos(tag.getInt("X"), tag.getInt("Y"), tag.getInt("Z")), type);
            node.setEnabled(tag.getBoolean("Enabled"));
            add(node);
        }
        for (int i = 0; i < list.size(); i++) {
            CompoundTag tag = list.getCompound(i);
            UUID from = tag.getUUID("Id");
            ListTag links = tag.getList("Connections", Tag.TAG_COMPOUND);
            for (int j = 0; j < links.size(); j++) {
                UUID to = links.getCompound(j).getUUID("Id");
                if (nodes.containsKey(from) && nodes.containsKey(to)) nodes.get(from).connect(to);
            }
        }
    }
}
