package com.livingcity.navigation;

import com.livingcity.entity.UrbanNPCEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Follows the high-level waypoint route one segment at a time.
 * Every segment is executed by PathfinderMob's native navigation/pathfinder.
 */
public final class NPCPathController {
    private final UrbanNPCEntity npc;
    private List<UUID> route = List.of();
    private int routeIndex;
    private int repathCooldown;

    public NPCPathController(UrbanNPCEntity npc) { this.npc = npc; }

    public boolean setRoute(CityRoute cityRoute, CityNavigationGraph graph) {
        if (cityRoute == null || cityRoute.isEmpty()) return false;
        route = cityRoute.waypointIds();
        routeIndex = route.size() > 1 ? 1 : 0;
        repathCooldown = 0;
        return moveToCurrent(graph);
    }

    public boolean tick(CityNavigationGraph graph) {
        if (route.isEmpty()) return false;
        if (routeIndex >= route.size()) {
            clear();
            return false;
        }

        CityWaypoint target = graph.get(route.get(routeIndex)).orElse(null);
        if (target == null || !target.enabled()) {
            clear();
            return false;
        }

        if (npc.blockPosition().distToCenterSqr(target.position()) < 2.25D) {
            routeIndex++;
            if (routeIndex >= route.size()) {
                clear();
                return false;
            }
            return moveToCurrent(graph);
        }

        if (repathCooldown > 0) repathCooldown--;
        if (!npc.getNavigation().isInProgress() && repathCooldown == 0) {
            repathCooldown = 30;
            return moveToCurrent(graph);
        }
        return true;
    }

    private boolean moveToCurrent(CityNavigationGraph graph) {
        if (routeIndex >= route.size()) {
            clear();
            return false;
        }
        CityWaypoint node = graph.get(route.get(routeIndex)).orElse(null);
        if (node == null || !node.enabled()) {
            clear();
            return false;
        }
        boolean accepted = npc.getNavigation().moveTo(
                node.position().getX() + 0.5D,
                node.position().getY(),
                node.position().getZ() + 0.5D,
                0.9D);
        if (!accepted) {
            clear();
            return false;
        }
        return true;
    }

    public List<Vec3> getDebugPoints(CityNavigationGraph graph) {
        List<Vec3> points = new ArrayList<>();
        for (int i = routeIndex; i < route.size(); i++) {
            CityWaypoint node = graph.get(route.get(i)).orElse(null);
            if (node != null) points.add(Vec3.atCenterOf(node.position()));
        }
        return List.copyOf(points);
    }

    public void clear() {
        route = List.of();
        routeIndex = 0;
        repathCooldown = 0;
        npc.getNavigation().stop();
    }

    public boolean hasRoute() { return !route.isEmpty(); }
    public int routeIndex() { return routeIndex; }
    public List<UUID> routeIds() { return route; }
}
