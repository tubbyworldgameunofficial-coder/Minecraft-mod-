package com.livingcity.navigation;

import net.minecraft.core.BlockPos;
import java.util.*;

public final class CityWaypoint {
    private final UUID id;
    private final BlockPos position;
    private final WaypointType type;
    private final Set<UUID> connections = new LinkedHashSet<>();
    private boolean enabled = true;

    public CityWaypoint(UUID id, BlockPos position, WaypointType type) {
        this.id = Objects.requireNonNull(id);
        this.position = Objects.requireNonNull(position).immutable();
        this.type = Objects.requireNonNull(type);
    }

    public UUID id() { return id; }
    public BlockPos position() { return position; }
    public WaypointType type() { return type; }
    public Set<UUID> connections() { return Collections.unmodifiableSet(connections); }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void connect(UUID other) { if (!id.equals(other)) connections.add(other); }
    public void disconnect(UUID other) { connections.remove(other); }

    public double distanceTo(CityWaypoint other) {
        return Math.sqrt(position.distToCenterSqr(other.position));
    }
}
