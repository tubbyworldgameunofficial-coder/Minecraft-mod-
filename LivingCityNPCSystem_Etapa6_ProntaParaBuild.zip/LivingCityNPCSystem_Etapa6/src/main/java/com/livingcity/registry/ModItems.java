package com.livingcity.registry;

import com.livingcity.LivingCity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LivingCity.MOD_ID);

    public static final RegistryObject<Item> URBAN_NPC_SPAWN_EGG =
            ITEMS.register("urban_npc_spawn_egg", () ->
                    new SpawnEggItem(ModEntities.URBAN_NPC, 0xB58A63, 0x354A62,
                            new Item.Properties()));

    private ModItems() {}
}
