package com.livingcity.registry;

import com.livingcity.LivingCity;
import com.livingcity.entity.UrbanNPCEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LivingCity.MOD_ID);

    public static final RegistryObject<EntityType<UrbanNPCEntity>> URBAN_NPC =
            ENTITY_TYPES.register("urban_npc", () ->
                    EntityType.Builder.of(UrbanNPCEntity::new, MobCategory.CREATURE)
                            .sized(0.6F, 1.8F)
                            .clientTrackingRange(10)
                            .updateInterval(3)
                            .build("urban_npc"));

    private ModEntities() {}
}
