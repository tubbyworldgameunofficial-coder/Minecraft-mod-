package com.livingcity.registry;

import com.livingcity.LivingCity;
import com.livingcity.entity.UrbanNPCEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LivingCity.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModCommonEvents {
    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.URBAN_NPC.get(), UrbanNPCEntity.createAttributes().build());
    }

    private ModCommonEvents() {}
}
