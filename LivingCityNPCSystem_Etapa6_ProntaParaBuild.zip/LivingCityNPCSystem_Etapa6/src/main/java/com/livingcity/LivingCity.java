package com.livingcity;

import com.livingcity.registry.ModEntities;
import com.livingcity.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LivingCity.MOD_ID)
public class LivingCity {
    public static final String MOD_ID = "livingcity";

    public LivingCity() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(bus);
        ModItems.ITEMS.register(bus);
    }
}
