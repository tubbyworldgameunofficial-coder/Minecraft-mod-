package com.livingcity.client;

import com.livingcity.LivingCity;
import com.livingcity.entity.UrbanNPCEntity;
import com.livingcity.registry.ModEntities;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LivingCity.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.URBAN_NPC.get(), UrbanNPCRenderer::new);
    }

    public static class UrbanNPCRenderer
            extends HumanoidMobRenderer<UrbanNPCEntity, UrbanNPCModel> {
        private static final ResourceLocation[] SKINS = new ResourceLocation[] {
                new ResourceLocation(LivingCity.MOD_ID, "textures/entity/skins/skin_01.png"),
                new ResourceLocation(LivingCity.MOD_ID, "textures/entity/skins/skin_02.png"),
                new ResourceLocation(LivingCity.MOD_ID, "textures/entity/skins/skin_03.png"),
                new ResourceLocation(LivingCity.MOD_ID, "textures/entity/skins/skin_04.png"),
                new ResourceLocation(LivingCity.MOD_ID, "textures/entity/skins/skin_05.png")
        };

        public UrbanNPCRenderer(EntityRendererProvider.Context context) {
            super(context, new UrbanNPCModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        }

        @Override
        public ResourceLocation getTextureLocation(UrbanNPCEntity entity) {
            return SKINS[entity.getSkinIndex()];
        }
    }
}
