package com.livingcity.client;

import com.livingcity.entity.NPCAnimationState;
import com.livingcity.entity.UrbanNPCEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Uses Minecraft's own classic player geometry and skin UV layout.
 * ModelLayers.PLAYER includes the head/hat, sleeves and trouser overlays.
 */
public class UrbanNPCModel extends PlayerModel<UrbanNPCEntity> {
    public UrbanNPCModel(ModelPart root) {
        super(root, false); // false = classic Steve arms (4 px), not slim/Alex.
    }

    @Override
    public void setupAnim(UrbanNPCEntity npc, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(npc, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        NPCAnimationState state = npc.getNpcState();
        if (state == NPCAnimationState.IDLE) {
            float breathe = Mth.sin(ageInTicks * 0.08F) * 0.025F;
            body.y = breathe;
            rightArm.xRot *= 0.85F;
            leftArm.xRot *= 0.85F;
        } else if (state == NPCAnimationState.TALKING) {
            float gesture = Mth.sin(ageInTicks * 0.35F) * 0.28F;
            rightArm.xRot -= 0.35F + gesture;
            leftArm.xRot -= 0.18F - gesture * 0.45F;
            rightArm.zRot = -0.12F;
            leftArm.zRot = 0.12F;
        } else if (state == NPCAnimationState.OBSERVING) {
            head.yRot += Mth.sin(ageInTicks * 0.045F) * 0.12F;
            head.xRot -= 0.08F;
        }
    }
}
