package com.livingcity.ai.goals;

import com.livingcity.entity.UrbanNPCEntity;
import com.livingcity.navigation.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;
import java.util.Optional;

/**
 * Crossing behavior for graph-authored crosswalk links.
 * A crossing is only attempted when the graph explicitly links the nodes and
 * the proposed segment passes conservative block-space checks.
 */
public class CrossStreetGoal extends Goal {
    private final UrbanNPCEntity npc;
    private CityWaypoint crossingTarget;
    private int retryCooldown;

    public CrossStreetGoal(UrbanNPCEntity npc) {
        this.npc = npc;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!(npc.level() instanceof ServerLevel level) || npc.isPassenger() || npc.isSleeping())
            return false;
        if (retryCooldown > 0) {
            retryCooldown--;
            return false;
        }

        CityNavigationGraph graph = CityNavigationSavedData.get(level).graph();
        Optional<CityWaypoint> current = graph.nearest(npc.blockPosition(), 5.0D);
        if (current.isEmpty()) return false;

        Optional<CityWaypoint> target = StreetCrossingManager.findOppositeCrosswalk(
                graph, current.get(), 20.0D);
        if (target.isEmpty()) return false;
        if (!StreetCrossingManager.isCrossing(current.get(), target.get())) return false;

        // Require an explicit graph edge; the crossing is not invented from proximity.
        if (!current.get().connections().contains(target.get().id())) return false;
        if (!StreetCrossingManager.isSegmentClear(level,
                current.get().position(), target.get().position())) return false;

        crossingTarget = target.get();
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return crossingTarget != null && npc.isAlive()
                && npc.blockPosition().distToCenterSqr(crossingTarget.position()) > 2.25D;
    }

    @Override
    public void start() {
        if (crossingTarget != null) {
            npc.getNavigation().moveTo(crossingTarget.position().getX() + 0.5D,
                    crossingTarget.position().getY(),
                    crossingTarget.position().getZ() + 0.5D, 0.8D);
        }
    }

    @Override
    public void tick() {
        if (crossingTarget == null) return;
        npc.getLookControl().setLookAt(crossingTarget.position().getX() + 0.5D,
                crossingTarget.position().getY() + 1.0D,
                crossingTarget.position().getZ() + 0.5D, 20.0F, 20.0F);
        if (!npc.getNavigation().isInProgress()
                && npc.blockPosition().distToCenterSqr(crossingTarget.position()) > 2.25D) {
            // Native navigation may reject a path if the world changed after planning.
            npc.getNavigation().moveTo(crossingTarget.position().getX() + 0.5D,
                    crossingTarget.position().getY(),
                    crossingTarget.position().getZ() + 0.5D, 0.8D);
        }
    }

    @Override
    public void stop() {
        crossingTarget = null;
        retryCooldown = 80;
        npc.refreshStateFromNavigation();
    }
}
