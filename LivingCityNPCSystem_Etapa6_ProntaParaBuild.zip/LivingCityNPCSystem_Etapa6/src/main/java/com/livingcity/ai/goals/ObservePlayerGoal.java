package com.livingcity.ai.goals;

import com.livingcity.entity.NPCAnimationState;
import com.livingcity.entity.UrbanNPCEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

public class ObservePlayerGoal extends Goal {
    private final UrbanNPCEntity npc;
    private final double range;
    private Player target;
    private int lookTime;

    public ObservePlayerGoal(UrbanNPCEntity npc, double range) {
        this.npc = npc;
        this.range = range;
        this.setFlags(EnumSet.of(Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (npc.isPassenger() || npc.isSleeping()) return false;
        target = npc.level().getNearestPlayer(npc, range);
        return target != null && !target.isSpectator();
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && !target.isSpectator()
                && npc.distanceToSqr(target) <= range * range && lookTime > 0;
    }

    @Override
    public void start() {
        lookTime = 40 + npc.getRandom().nextInt(40);
        npc.setNpcState(NPCAnimationState.OBSERVING);
    }

    @Override
    public void tick() {
        if (target != null) npc.getLookControl().setLookAt(target, 30.0F, 30.0F);
        lookTime--;
    }

    @Override
    public void stop() {
        target = null;
        npc.refreshStateFromNavigation();
    }
}
