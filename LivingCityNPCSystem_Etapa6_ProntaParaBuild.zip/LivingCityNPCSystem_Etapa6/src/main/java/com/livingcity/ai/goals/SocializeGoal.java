package com.livingcity.ai.goals;

import com.livingcity.entity.NPCAnimationState;
import com.livingcity.entity.NPCPersonality;
import com.livingcity.entity.UrbanNPCEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;
import java.util.List;

public class SocializeGoal extends Goal {
    private final UrbanNPCEntity npc;
    private UrbanNPCEntity partner;
    private int interactionTicks;
    private int cooldown;

    public SocializeGoal(UrbanNPCEntity npc) {
        this.npc = npc;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        if (npc.getPersonality().socialChance() <= 0.0D || npc.isPassenger()) return false;

        List<UrbanNPCEntity> nearby = npc.level().getEntitiesOfClass(
                UrbanNPCEntity.class, npc.getBoundingBox().inflate(7.0D),
                other -> other != npc && other.isAlive()
                        && other.getNpcState() != NPCAnimationState.TALKING);
        if (nearby.isEmpty()) return false;

        partner = nearby.stream()
                .filter(other -> other.distanceToSqr(npc) > 1.5D)
                .min((a, b) -> Double.compare(a.distanceToSqr(npc), b.distanceToSqr(npc)))
                .orElse(null);
        return partner != null && npc.getRandom().nextDouble() < npc.getPersonality().socialChance();
    }

    @Override
    public boolean canContinueToUse() {
        return partner != null && partner.isAlive() && interactionTicks > 0
                && npc.distanceToSqr(partner) <= 100.0D;
    }

    @Override
    public void start() {
        interactionTicks = 60 + npc.getRandom().nextInt(100);
        npc.getNavigation().moveTo(partner, 0.75D);
    }

    @Override
    public void tick() {
        if (partner == null) return;
        npc.getLookControl().setLookAt(partner, 30.0F, 30.0F);
        if (npc.distanceToSqr(partner) <= 6.25D) {
            npc.getNavigation().stop();
            npc.setNpcState(NPCAnimationState.TALKING);
            partner.getLookControl().setLookAt(npc, 30.0F, 30.0F);
            partner.setNpcState(NPCAnimationState.TALKING);
        } else if (!npc.getNavigation().isInProgress()) {
            npc.getNavigation().moveTo(partner, 0.75D);
        }
        interactionTicks--;
    }

    @Override
    public void stop() {
        if (partner != null && partner.isAlive()) partner.refreshStateFromNavigation();
        partner = null;
        cooldown = 100 + npc.getRandom().nextInt(160);
        npc.refreshStateFromNavigation();
    }
}
