package com.livingcity.ai.goals;

import com.livingcity.entity.UrbanNPCEntity;
import com.livingcity.navigation.CityNavigationGraph;
import com.livingcity.navigation.CityNavigationSavedData;
import com.livingcity.navigation.CityRoute;
import com.livingcity.navigation.CityWaypoint;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Assigns an A* route in the urban graph and delegates movement along each
 * waypoint segment to the entity's native PathfinderMob navigation.
 */
public class UrbanGraphNavigationGoal extends Goal {
    private final UrbanNPCEntity npc;
    private final double searchRadius;
    private int decisionCooldown;

    public UrbanGraphNavigationGoal(UrbanNPCEntity npc, double searchRadius) {
        this.npc = npc;
        this.searchRadius = searchRadius;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!(npc.level() instanceof ServerLevel level) || npc.isPassenger() || npc.isSleeping())
            return false;

        if (npc.getCityPath().hasRoute()) return true;
        if (decisionCooldown > 0) {
            decisionCooldown--;
            return false;
        }
        decisionCooldown = 60 + npc.getRandom().nextInt(80);

        CityNavigationGraph graph = CityNavigationSavedData.get(level).graph();
        if (graph.size() < 2) return false;

        Optional<CityWaypoint> start = graph.nearest(npc.blockPosition(), searchRadius);
        if (start.isEmpty()) return false;

        List<CityWaypoint> candidates = new ArrayList<>();
        for (CityWaypoint node : graph.nodes()) {
            if (node.enabled() && !node.id().equals(start.get().id())
                    && node.position().distToCenterSqr(npc.blockPosition()) <= searchRadius * searchRadius * 9.0D) {
                candidates.add(node);
            }
        }
        if (candidates.isEmpty()) return false;

        // Try a bounded number of destinations so a disconnected graph does not
        // cause an unbounded search on the server thread.
        int attempts = Math.min(8, candidates.size());
        for (int i = 0; i < attempts; i++) {
            CityWaypoint destination = candidates.get(npc.getRandom().nextInt(candidates.size()));
            Optional<CityRoute> route = graph.findRoute(start.get().id(), destination.id());
            if (route.isPresent() && route.get().waypointIds().size() > 1) {
                if (npc.getCityPath().setRoute(route.get(), graph)) return true;
            }
            candidates.remove(destination);
            if (candidates.isEmpty()) break;
        }
        return false;
    }

    @Override
    public boolean canContinueToUse() {
        return npc.getCityPath().hasRoute() && npc.isAlive();
    }

    @Override
    public void start() {
        npc.refreshStateFromNavigation();
    }

    @Override
    public void tick() {
        if (!(npc.level() instanceof ServerLevel level)) return;
        CityNavigationGraph graph = CityNavigationSavedData.get(level).graph();
        if (!npc.getCityPath().tick(graph)) {
            npc.refreshStateFromNavigation();
        }
    }

    @Override
    public void stop() {
        // Do not discard the route when another higher-priority action (e.g. a
        // short social interaction) temporarily takes control of movement.
        npc.refreshStateFromNavigation();
    }
}
