package com.livingcity.ai;

import com.livingcity.entity.NPCPersonality;
import com.livingcity.entity.UrbanNPCEntity;
import net.minecraft.util.RandomSource;

/**
 * Small, server-authoritative decision layer.
 * Expensive or social decisions are sampled periodically rather than every tick.
 */
public final class NPCBrain {
    private NPCBrain() {}

    public static void serverThink(UrbanNPCEntity npc) {
        if (npc.level().isClientSide || npc.isRemoved()) return;
        if (npc.tickCount % 40 != 0) return;

        RandomSource random = npc.getRandom();
        NPCPersonality personality = npc.getPersonality();

        // Personality slightly changes preferred movement speed without forcing
        // a new path every decision interval.
        double base = 0.25D * personality.walkMultiplier();
        npc.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                .setBaseValue(base);

        // Occasionally pause to look around; active goals retain control of movement.
        if (!npc.getNavigation().isInProgress() && random.nextFloat() < 0.16F) {
            npc.setNpcState(com.livingcity.entity.NPCAnimationState.OBSERVING);
        }
    }
}
