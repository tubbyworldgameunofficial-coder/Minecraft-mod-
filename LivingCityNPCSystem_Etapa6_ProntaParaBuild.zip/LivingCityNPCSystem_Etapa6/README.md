# Living City NPC System — Etapa 6

**Base:** Etapa 5  
**Alvo:** Minecraft Java 1.20.1 / Forge 47.2.0 / Java 17

## O que entrou nesta etapa

- Modelo de personagem baseado na geometria humanoide clássica nativa do Minecraft (`ModelLayers.PLAYER`).
- Proporções clássicas Steve: braços de 4 px; inclui as camadas externas de cabeça/chapéu, mangas e calças do modelo de jogador.
- As cinco skins PNG 64x64 do pacote enviado foram copiadas sem redesenhar suas imagens para `assets/livingcity/textures/entity/skins/`.
- Cada NPC recebe uma das cinco skins ao nascer; o índice é sincronizado aos clientes e salvo no NBT.
- Animações simples para idle, conversa e observação, além da animação de caminhada herdada do modelo de jogador.
- O OBJ original foi guardado como referência em `models/entity/reference_obj/`.

## Importante sobre o OBJ

O arquivo OBJ do ZIP é preservado como referência do modelo. O renderizador de entidades do Forge 1.20.1 não carrega OBJ diretamente como malha de entidade. Para que o personagem funcione dentro do jogo, esta etapa usa a malha humanoide clássica nativa do Minecraft, que corresponde ao formato de personagem/skin 64x64 e oferece as camadas externas da skin. Assim, não há conversão OBJ improvisada nem perda da aplicação das texturas.

## Escolha de skin

O NPC escolhe aleatoriamente uma skin de 0 a 4 no primeiro tick do servidor. O método `setSkinIndex(int)` permite que uma futura etapa de comandos/menus selecione a skin manualmente. O valor fica entre 0 e 4.

## Limitações e validação

Este pacote é código-fonte. Não foi possível executar Gradle nem iniciar Minecraft/Forge neste ambiente; portanto, **não afirmo que o JAR compila ou que o teste dentro do jogo foi aprovado**. A etapa seguinte deve compilar em ambiente Forge 1.20.1, corrigir eventuais incompatibilidades de API e testar as cinco texturas e animações no cliente.
