@echo off
cd /d %~dp0
gradle --version
if errorlevel 1 (echo Instale Gradle 8.x e Java 17 antes de compilar.& pause & exit /b 1)
gradle clean build
if errorlevel 1 (echo A compilacao falhou. Veja os erros acima.& pause & exit /b 1)
echo JAR gerado em build\libs\LivingCity-0.1.0.jar
pause
